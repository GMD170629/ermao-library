# Import Guide

[Home](Home) · [简体中文](zh-CN-Import-Guide) · [User Guide](en-US-User-Guide) · [Supported Formats](en-US-Supported-Formats)

This guide covers the two import methods, watched-folder configuration, every import preference, naming conventions for ebooks/documents, comics, and audiobooks, and safe cleanup and re-import procedures.

## Import model

- Original files remain under `MONITOR_ROOT`, normally `/monitor` in Docker.
- The database stores works, editions, volumes, tasks, and progress.
- MOBI, AZW, AZW3, PRC, FB2, and TXT can produce a derived EPUB while retaining the source.
- Watched-folder scans are recursive.
- A successfully imported known path is normally skipped to prevent duplicates.

Test one item of each media type before starting a large import.

## Two import methods

| Method | Best for | Behavior |
| --- | --- | --- |
| Browser upload | A few files, mobile use, manually combining audio tracks | Saves to a selected directory and immediately queues the file |
| File import | Existing NAS libraries, bulk import, continuous discovery | Scans enabled watched folders and detects later additions |

Both methods apply the global extension and ignore settings. File import also applies the selected watched folder's hidden-file, minimum-size, and local ignore rules.

## Browser upload

1. Open **All Books**.
2. Select **Import Book**.
3. Choose one ebook, PDF, or comic; or choose one or more MP3/M4A/M4B files.
4. For audio, optionally enter a book title and author. Explicit values take precedence over tags and filenames.
5. Select a destination inside `MONITOR_ROOT`.
6. Select **Start Import**.
7. Follow progress under **Settings → Library Sources and Import → Import History**.

Uploads are first written to a temporary `.part` path. Multiple audio files are placed in a separate `Title-Audiobook` directory and queued as one audiobook. Non-audio files must be uploaded one book at a time.

If upload fails, check the enabled extension, global ignore rules, destination permission, reverse-proxy body-size limit, and whether every selected multi-file asset is audio.

## File import

### Docker mapping

```yaml
volumes:
  - ${MONITOR_HOST_PATH:-./monitor}:/monitor
  - ${STORAGE_PATH:-./data/storage}:/app/storage
```

Enter container paths such as `/monitor/ebooks` in the application, not host paths such as `/volume1/books`.

### Which path to enter

Every path in the application is an absolute path visible to the application runtime:

| Deployment | Actual storage directory | Path entered in the application |
| --- | --- | --- |
| Docker / NAS | `/volume1/books` mounted at `/monitor` | `/monitor` or a child path |
| Docker Compose relative directory | `./monitor` mounted at `/monitor` | `/monitor` |
| Non-container local deployment | `MONITOR_ROOT=/home/user/books` | `/home/user/books` or a child path |

Important:

- Do not enter a host path in a Docker deployment; that path is not directly visible inside the container.
- A watched folder must stay inside `MONITOR_ROOT` and remain enabled.
- Scans are recursive, so there is no need to configure one watched folder per book.
- A directory selected in **File Management** must be inside an enabled watched folder and uses that folder's recognition rules.
- Do not move or delete a source after it has been queued. If the path is missing when the worker processes it, the task ends as failed; recognize the corrected path again.
- Successfully imported paths are skipped. If any track of a multi-volume audiobook is already in the library, the importer will not regroup the old work or migrate its progress automatically.

### Add a watched folder

Open **Settings → Library Sources and Import → Watched Folders**, then configure:

| Setting | Meaning |
| --- | --- |
| Name | Display name for the source; it does not rename the directory |
| Watched folder path | Absolute container path inside the monitor root |
| Custom ignore patterns | One glob rule per line, scoped to this folder |
| Minimum file size (KB) | Files smaller than this are skipped; `0` disables the limit |
| Ignore hidden files | Skips content with a path component beginning with `.` |
| Enabled switch | Starts/stops discovery without deleting source files |

Save and enable the folder. Existing and future supported files are then eligible for recursive scanning.

### Automatic and manual recognition

Enabled folders watch for new files. To scan one directory manually:

1. Open **Library Sources and Import → File Management**.
2. Select a directory inside an enabled watched folder.
3. Confirm which watched-folder rules will be used.
4. Select **Recognize This Directory**.
5. Review scanned, queued, skipped, and failed counts.

Manual recognition still applies format, hidden-file, size, ignore, and already-imported checks.

## Import preferences

Open **Library Sources and Import → Preferences**.

### File stability check

The worker waits until file size and modification time stop changing.

- Recommended for NAS copies and downloads.
- Range: `0.5`–`300` seconds; default `2`.
- Use a longer interval for large archives, audiobooks, or slow shares.

### Automatic EPUB conversion

When enabled, MOBI, AZW, AZW3, PRC, FB2, and TXT generate a validated EPUB while retaining the source. When disabled, the source is still imported, but the current reader cannot open it until it is converted later.

### Allowed extensions

- Ebooks: EPUB, MOBI, AZW, AZW3, PRC, FB2, TXT
- Documents and comics: PDF, CBZ, ZIP
- Audiobooks: M4B, M4A, MP3

Disabling an extension affects uploads, watched scans, manual directory recognition, and background imports. It does not delete existing library items.

### Global ignore patterns

One pattern per line:

```text
*.part
*.tmp
~$*
scanned-copy*
*/cache/*
*/@eaDir/*
```

Patterns match filenames or normalized paths and are combined with folder-specific patterns. Global rules also affect browser upload. Up to 200 non-empty rules are retained.

### Folder-specific scan rules

Each watched folder can add local ignore patterns, hidden-file behavior, and a minimum size. Built-in scanning also ignores covers, thumbnails, temporary files, documentation files, and ordinary loose images. Comics must be packaged as CBZ/ZIP.

## General naming

Prefer:

```text
[Book Title][Author].extension
Book Title - Author.extension
```

Use consistent title and author spelling, explicit zero-padded volume numbers, and real extensions. Avoid ambiguous names such as `001.epub`, `final.zip`, or `new file.mp3`.

## Ebooks and documents

For single books:

```text
[The Left Hand of Darkness][Ursula K. Le Guin].epub
Book Title - Author.pdf
```

For series:

```text
[Series Title][Author][Vol.01-Vol.10]/
├── Series Title Vol.01.epub
├── Series Title Vol.02.epub
└── Series Title Vol.10.epub
```

Volume-only filenames are also supported inside an identified parent:

```text
[Series Title][Author]/
├── Vol.01.epub
└── Vol.02.epub
```

EPUB OPF and PDF metadata are read, but filenames and directories remain important for work identity and merging.

## Comics

Use one CBZ/ZIP per volume:

```text
[Comic Title][Author][Vol.01-Vol.20]/
├── Comic Title Vol.01.cbz
└── Comic Title Vol.02.cbz
```

Archive layout:

```text
Comic Title Vol.01.cbz
├── ComicInfo.xml
├── 001.jpg
├── 002.jpg
└── 120.jpg
```

Pages use natural filename order; zero-padding is still recommended. `ComicInfo.xml` can provide series, volume, creator, publisher, summary, tags, and cover selection. Otherwise, the directory and archive name identify the work and volume. Loose image directories are not imported as comics.

## Audiobooks

Single file:

```text
[Book Title][Author].m4b
```

Single-volume split book:

```text
[Book Title][Author]/
├── 001 - Chapter One.mp3
├── 002 - Chapter Two.mp3
└── 003 - Chapter Three.mp3
```

`Disc`, `CD`, and `Disk` directories are physical track-grouping layers, not business volumes:

```text
[Book Title][Author]/
├── Disc 1/
│   ├── 01 - Chapter One.mp3
│   └── 02 - Chapter Two.mp3
└── Disc 2/
    └── 01 - Chapter Three.mp3
```

Multi-volume audiobook:

```text
[Book Title][Author]/
├── Book Title Vol.1/
│   ├── 001 - Chapter One.mp3
│   └── 002 - Chapter Two.mp3
├── Book Title Vol.2/
│   └── ...
└── Book Title Vol.3/
    ├── Disc 1/
    │   └── 001 - Chapter One.mp3
    └── Disc 2/
        └── ...
```

Each matching child directory becomes a separate library volume. Display titles preserve directory names. Parsed identifiers such as `Vol.1`, `Volume 1`, `V1`, or their supported Chinese equivalents determine volume order; otherwise natural directory order is used.

Child directories are classified in this order:

1. A child with a recognized volume number is a volume.
2. After embedded author and volume markers are removed, a child title containing the normalized parent book title is a volume.
3. A child matching neither rule is recursively recognized as an independent audiobook.

Do not mix direct tracks and explicit volume directories under one book directory. The whole import fails safely instead of silently assigning the direct tracks to the wrong volume.

### Title and author recognition

Before matching path levels, the importer applies the existing identity rules to the same directory name. Names such as `[Book Title][Author]`, `Book Title - Author`, and `Book Title Vol.1` are parsed before title containment is evaluated.

Author precedence is:

1. an explicit author entered during browser upload;
2. an author embedded in the book directory;
3. one consistent author embedded across volume directories;
4. one consistent author from audio tags;
5. unknown author.

A separate `Author/Book/Tracks` hierarchy no longer assigns the parent directory as the author. The `Book` child is recognized independently. Embed the author in the book directory, keep audio tags consistent, or enter it explicitly during upload.

Important rules:

- The book directory is the work boundary and each matching volume directory is a volume boundary.
- One multi-volume directory creates one import task and one audiobook edition with separate library volumes.
- Keep different audiobooks in separate directories.
- Keep album/title and author tags consistent.
- In a mixed-media directory, prefix tracks with `01 -`, `Track 01`, `Chapter 01`, or an explicit episode label.
- Distinct paths containing byte-identical audio are allowed as separate chapters.
- If any track already belongs to other library content, a multi-volume import fails without creating partial volumes or changing existing progress.
- Ordering uses disc number, complete unique embedded track numbers, filename episode numbers, then natural filename order.

Strict flat naming can merge files directly under the monitor root:

```text
01- Flat Book - Chapter 01.mp3
02- Flat Book - Chapter 02.mp3
10- Flat Book - Chapter 10.mp3
```

A per-book directory remains the safer choice.

Browser multi-file upload continues to create a single-volume audiobook. To import multiple volumes, place the complete organized directory in a watched folder and use automatic scanning or **File Management → Recognize This Directory**.

## Fix and re-import

### Metadata-only issue

Edit title, author, cover, or tags from the work detail view. Re-import is unnecessary for presentation-only corrections.

### Transient failure

Open the failed import task, fix the reported permission, conversion, or file-integrity problem, then select **Retry Import** or **Retry Automatic Conversion**.

### Wrong filename, volume, or audio grouping

1. Back up the source.
2. Open the relevant import task and select **Delete**.
3. Choose **Delete import record only**, or **Delete converted file too** when a bad derived EPUB exists.
4. Enable **Delete linked volume or edition**.
5. Confirm deletion.
6. Rename/restructure the source on the NAS.
7. Run **Recognize This Directory** or rescan all watched folders.
8. Confirm the new task and resulting work structure.

Deleting a linked volume/edition removes only the directly associated structure, progress, and generated files. Other editions and volumes remain.

### Remove a bad upload completely

Choose **Delete source file too** and **Delete linked volume or edition**, confirm the exact target, and upload a correctly named replacement. Source deletion cannot be undone. For automatically converted text formats, retaining the source, deleting the derived file, renaming the source, and rescanning is usually safer.

### History cleanup is not undo

**Delete import record only** and **Clean Finished History** preserve source files, converted files, works, editions, and progress. They do not undo an import.

If a rescan still skips the item, check for an existing completed task or edition, duplicate content, a disabled extension, ignore-rule match, minimum-size filter, or a file that is still changing.

## Recommended first bulk import

1. Back up the source directories.
2. Separate ebooks, comics, and audiobooks.
3. Add one correctly named sample of each type.
4. Configure watched folders and preferences.
5. Manually recognize the sample directories.
6. Verify identity, volumes, covers, chapters, and audio order.
7. Copy the remaining collection only after the samples are correct.
8. Review failed tasks and create both database and directory backups.
