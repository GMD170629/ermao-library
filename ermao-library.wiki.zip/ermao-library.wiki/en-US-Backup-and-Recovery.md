# Backup and Recovery

[Home](Home) · [简体中文](zh-CN-Backup-and-Recovery) · [Installation](en-US-Installation)

Ermao Books separates application data from original reading files. A reliable backup must cover both.

## Data locations

| Data | Default location | Purpose |
| --- | --- | --- |
| SQLite database | `STORAGE_ROOT/database/shuku.sqlite3` | Accounts, library records, progress, and settings |
| Application storage | Host `STORAGE_PATH` | Database, derived files, cache, logs, and session keys |
| Original reading files | Host `MONITOR_HOST_PATH` | Source ebooks, PDFs, comics, and audiobooks |

## In-application backup

Database backups can be created and restored from Settings. `POST /api/backups` can also create a backup archive.

An application backup includes database data and system settings, but excludes:

- original reading files;
- reader content files;
- cover image files;
- host-level `compose.yaml` and `.env`.

An application backup is therefore not a replacement for a directory-level backup.

## Recommended strategy

Keep all of the following:

1. An application-generated database backup archive.
2. The complete `STORAGE_PATH`.
3. The complete `MONITOR_HOST_PATH`.
4. `compose.yaml` and a securely stored `.env`.

Apply the `3-2-1` principle where possible: three copies, two media types, and one off-site or offline copy.

## Consistent directory backup

The safest procedure is:

```bash
docker compose stop web
# Copy STORAGE_PATH and MONITOR_HOST_PATH with snapshots, rsync, or another backup tool.
docker compose start web
```

An atomic storage snapshot is also suitable after writes are briefly stopped. Avoid copying only a busy SQLite file and assuming it is necessarily consistent.

## Restore

1. Stop the container.
2. Preserve the current damaged or replaced data for rollback.
3. Restore the complete `STORAGE_PATH`.
4. Restore `MONITOR_HOST_PATH` while preserving its directory structure.
5. Correct UID/GID ownership and permissions.
6. Start the container.
7. Verify health, sign-in, work counts, progress, and file access.

```bash
docker compose up -d
docker compose logs --tail=100 web
curl http://127.0.0.1:3000/api/health
```

## Common post-restore issues

- **Cannot sign in:** make sure the database and session keys came from the same backup set.
- **Works exist but files fail to open:** confirm original files are restored and still mounted at `/monitor`.
- **Permission errors:** align `PUID`/`PGID` with restored directory ownership.
- **Covers are temporarily missing:** caches may need to be regenerated.
- **Duplicate imports:** do not immediately rescan an unverified duplicate directory tree.

Always preserve the current data before recovery. Do not overwrite the only database copy.
