# 快速开始

[返回首页](Home) · [English](en-US-Quick-Start) · [完整安装说明](zh-CN-Installation)

推荐使用 Docker Compose 部署。生产镜像同时支持 `linux/amd64` 和 `linux/arm64`。

## 1. 准备目录

在 NAS 或服务器上建立一个部署目录：

```bash
mkdir -p ermao-library/monitor ermao-library/data/storage
cd ermao-library
```

- `monitor`：保存原始电子书、PDF、漫画和有声书
- `data/storage`：保存 SQLite 数据库、派生 EPUB、封面缓存、日志和会话密钥

## 2. 创建 `compose.yaml`

```yaml
name: shuku-starship

services:
  web:
    image: gamersgu/shuku-starship-web:prod
    pull_policy: always
    container_name: shuku-prod-web
    restart: unless-stopped
    user: "${PUID:-1000}:${PGID:-1000}"
    environment:
      STORAGE_ROOT: /app/storage
      MONITOR_ROOT: /monitor
      PORT: 3000
      HOSTNAME: 0.0.0.0
    ports:
      - "${WEB_PORT:-3000}:3000"
    volumes:
      - ${STORAGE_PATH:-./data/storage}:/app/storage
      - ${MONITOR_HOST_PATH:-./monitor}:/monitor
    command: ["./scripts/start-unified-app.sh"]
    healthcheck:
      test: ["CMD-SHELL", "node -e \"fetch('http://127.0.0.1:3000/api/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))\""]
      interval: 30s
      timeout: 5s
      retries: 5
      start_period: 30s
```

## 3. 启动

```bash
docker compose up -d
docker compose ps
```

浏览器访问：

```text
http://服务器地址:3000
```

## 4. 完成首次设置

1. 根据向导创建初始管理员账户。
2. 添加 `/monitor` 或其子目录作为监控文件夹。
3. 将读物放进宿主机的 `monitor` 目录，或在“全部图书”页面上传文件。
4. 在导入任务中查看解析或转换进度。
5. 按需配置元数据来源、SMTP 和 Kindle 邮箱。

应用不提供默认账号和密码。首次打开空数据库时，必须通过设置向导创建管理员。

## 5. 检查运行状态

```bash
docker compose logs --tail=100 web
curl http://127.0.0.1:3000/api/health
```

如遇到目录不可写、容器反复重启或文件无法导入，请查看[故障排查](zh-CN-Troubleshooting)。

## 更新

```bash
docker compose pull
docker compose up -d
```

只要目录挂载保持不变，更新或重建容器不会清空书库与数据库。
