# Configuration

[Home](Home) · [简体中文](zh-CN-Configuration) · [Installation](en-US-Installation)

Docker Compose reads variables from a colocated `.env` file and the service `environment` section. Do not commit production secrets to a public repository.

## Docker Compose variables

| Variable | Default | Description |
| --- | --- | --- |
| `WEB_PORT` | `3000` | Host web port |
| `PUID` | `1000` | Host user ID used by the container |
| `PGID` | `1000` | Host group ID used by the container |
| `MONITOR_HOST_PATH` | `./monitor` | Host directory containing original reading files |
| `STORAGE_PATH` | `./data/storage` | Host application data directory |

## Application variables

| Variable | Example/default | Description |
| --- | --- | --- |
| `STORAGE_ROOT` | `/app/storage` | Application data root inside the container |
| `MONITOR_ROOT` | `/monitor` | Browsable and watchable root inside the container |
| `PUBLIC_APP_URL` | `https://books.example.com` | External application URL |
| `SESSION_SECRET` | 32+ characters | Session signing secret; use a random production value |
| `EBOOK_CONVERSION_ENABLED` | `true` | Enables automatic text-ebook conversion |
| `LIBMOBI_BIN` | `mobitool` | libmobi executable name or path |
| `EBOOK_CONVERSION_TIMEOUT_SECONDS` | `600` | Per-conversion timeout in seconds |
| `FILE_STREAMS_PER_USER` | `4` | Concurrent file streams per user |
| `SLOW_FILE_REQUEST_MS` | `1500` | Slow file-request threshold |
| `KINDLE_SEND_QUEUE_ENABLED` | `true` | Enables the Kindle delivery queue |
| `KINDLE_SEND_QUEUE_INTERVAL_SECONDS` | `5` | Kindle queue polling interval |

`STORAGE_ROOT` and `MONITOR_ROOT` are container paths. In a normal Docker deployment, do not replace them with host paths.

## Session secret

Generate a production secret:

```bash
openssl rand -hex 32
```

Add it to `.env`:

```dotenv
SESSION_SECRET=your-generated-random-value
```

When the application creates a session key automatically, it is kept in persistent storage. Copy the complete `STORAGE_PATH` when moving the service.

## SMTP and Kindle

SMTP and the Kindle recipient are primarily managed under **Settings → Email and Kindle**. Deployment variables include:

```dotenv
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USERNAME=
SMTP_PASSWORD=
SMTP_FROM=books@example.com
SMTP_STARTTLS=true
SMTP_USE_SSL=false
KINDLE_SEND_QUEUE_ENABLED=true
KINDLE_SEND_QUEUE_INTERVAL_SECONDS=5
```

- Port `587` commonly uses `SMTP_STARTTLS=true`.
- Port `465` commonly uses `SMTP_USE_SSL=true`.
- Do not enable incompatible TLS modes together.
- The sender must meet the mail provider's verification requirements.
- Add the sender to the approved personal-document email list in the Kindle account.

## Reverse-proxy URL

For an HTTPS domain:

```dotenv
PUBLIC_APP_URL=https://books.example.com
```

The application uses this value for externally reachable links. The proxy must preserve the original host and protocol headers.

## Apply changes

```bash
docker compose up -d
docker compose logs --tail=100 web
```

Compose recreates the service when the effective environment changes.

Complete example: [`.env.production.example`](https://github.com/GMD170629/ermao-library/blob/main/.env.production.example)
