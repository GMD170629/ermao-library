# Architecture

[Home](Home) · [简体中文](zh-CN-Architecture) · [Development](en-US-Development)

Production uses one unified image with one public web port.

```mermaid
flowchart LR
    Client["Browser / PWA"] -->|HTTP 3000| Web["Next.js Web"]
    Web -->|/api/*| API["FastAPI API<br/>127.0.0.1:8000"]
    API --> DB["SQLite"]
    API --> Storage["Application storage<br/>/app/storage"]
    Worker["Python Import Worker"] --> DB
    Worker --> Monitor["Original files<br/>/monitor"]
    Worker --> Storage
    Web --> Monitor
```

## Components

### Next.js Web

- Next.js 14, React 18, TypeScript, and Tailwind CSS
- Desktop, mobile, and PWA interfaces
- Library, detail, settings, reader, and player views
- Proxies `/api/*` to FastAPI inside the container

### FastAPI API

- Python, FastAPI, and SQLAlchemy
- Accounts, library data, settings, backups, health, and media APIs
- Initializes and upgrades the SQLite schema at startup
- Listens on `127.0.0.1:8000` inside the unified container

### Python worker

- Processes persistent import and watch queues
- Uses Watchdog to observe configured folders
- Extracts metadata, covers, chapters, audio data, and comic pages
- Uses libmobi, EbookLib, lxml, Mutagen, and related components
- Converts supported text ebooks to EPUB

### SQLite

SQLite is the only currently supported database:

```text
STORAGE_ROOT/database/shuku.sqlite3
```

It stores accounts, works, editions, import tasks, progress, and settings. Original reading files are not stored in the database.

## File boundaries

- `/monitor`: original reading files and allowed watch/upload destinations
- `/app/storage`: database, session keys, cache, logs, and derived files
- source files remain after conversion and import
- directory backups must cover both mount points

## Readers and players

- EPUB: official EPUB.js npm dependency plus the application's adapter layer
- PDF: PDF.js
- Comics: project-owned comic reader adapter
- Audiobooks: HTML5 Audio and application playback state

EPUB.js is treated as an immutable third-party dependency. Reader behavior is implemented through its public APIs in project-owned controller, presentation, and input code.

## Internationalization

The Web app supports `zh-CN` and `en-US`. Shared messages live under `apps/web/i18n`; dates, numbers, and dynamic content follow the active locale.

## Runtime and health

The unified startup launches:

```text
uvicorn app.main:app
python -m app.worker.main
node apps/web/server.js
```

Health endpoints:

```text
/api/health
/api/system/health
```

Only the Web port needs to be published. The API and worker cooperate inside the unified container.
