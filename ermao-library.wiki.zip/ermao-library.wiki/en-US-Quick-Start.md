# Quick Start

[Home](Home) · [简体中文](zh-CN-Quick-Start) · [Full installation guide](en-US-Installation)

Docker Compose is the recommended deployment method. The production image supports both `linux/amd64` and `linux/arm64`.

## 1. Prepare directories

```bash
mkdir -p ermao-library/monitor ermao-library/data/storage
cd ermao-library
```

- `monitor` stores original ebooks, PDFs, comics, and audiobooks.
- `data/storage` stores the SQLite database, derived EPUB files, cover cache, logs, and session keys.

## 2. Create `compose.yaml`

```yaml
name: shuku-starship

services:
  web:
    image: gamersgu/shuku-starship-web:prod
    pull_policy: always
    container_name: shuku-prod-web
    restart: unless-stopped
    user: "${PUID:-1000}:${PGID:-1000}"
    environment:
      STORAGE_ROOT: /app/storage
      MONITOR_ROOT: /monitor
      PORT: 3000
      HOSTNAME: 0.0.0.0
    ports:
      - "${WEB_PORT:-3000}:3000"
    volumes:
      - ${STORAGE_PATH:-./data/storage}:/app/storage
      - ${MONITOR_HOST_PATH:-./monitor}:/monitor
    command: ["./scripts/start-unified-app.sh"]
    healthcheck:
      test: ["CMD-SHELL", "node -e \"fetch('http://127.0.0.1:3000/api/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))\""]
      interval: 30s
      timeout: 5s
      retries: 5
      start_period: 30s
```

## 3. Start the application

```bash
docker compose up -d
docker compose ps
```

Open:

```text
http://your-server-address:3000
```

## 4. Complete first-time setup

1. Follow the setup wizard to create the initial administrator.
2. Add `/monitor` or one of its subdirectories as a watched folder.
3. Put reading files in the host `monitor` directory, or upload them from **All Books**.
4. Track parsing and conversion in the import task list.
5. Configure metadata providers, SMTP, and a Kindle address as needed.

There is no default username or password. An empty database must be initialized through the setup wizard.

## 5. Check the service

```bash
docker compose logs --tail=100 web
curl http://127.0.0.1:3000/api/health
```

For permission, restart, or import problems, see [Troubleshooting](en-US-Troubleshooting).

## Update

```bash
docker compose pull
docker compose up -d
```

Updating or recreating the container does not erase data when the same host directories remain mounted.
