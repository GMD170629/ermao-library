# 备份与恢复

[返回首页](Home) · [English](en-US-Backup-and-Recovery) · [安装与更新](zh-CN-Installation)

二毛图书的数据分为“应用数据”和“原始读物”。可靠备份必须同时覆盖两者。

## 数据位置

| 数据 | 默认位置 | 重要性 |
| --- | --- | --- |
| SQLite 数据库 | `STORAGE_ROOT/database/shuku.sqlite3` | 账户、书库记录、进度和设置 |
| 应用存储 | 宿主机 `STORAGE_PATH` | 数据库、派生文件、缓存、日志和会话密钥 |
| 原始读物 | 宿主机 `MONITOR_HOST_PATH` | EPUB、PDF、漫画、有声书等源文件 |

## 应用内备份

可以在设置页面创建和恢复数据库备份。也可以通过 `POST /api/backups` 创建备份归档。

应用备份包含数据库数据和系统设置，但不包含：

- 原始读物文件
- 阅读器内容文件
- 封面图片文件
- 宿主机级的 Docker Compose 和 `.env`

因此，应用内备份不能替代目录级备份。

## 推荐备份策略

至少保存：

1. 应用生成的数据库备份归档。
2. 完整的 `STORAGE_PATH`。
3. 完整的 `MONITOR_HOST_PATH`。
4. `compose.yaml` 和不公开保存的 `.env`。

建议使用 `3-2-1` 原则：三份数据、两种介质、至少一份异地或离线副本。

## 一致性备份

最稳妥的目录级备份流程：

```bash
docker compose stop web
# 使用 NAS 快照、rsync 或其他备份工具复制 STORAGE_PATH 和 MONITOR_HOST_PATH
docker compose start web
```

如果存储系统支持原子快照，也可以在短暂停止写入后创建快照。不要在数据库频繁写入时只复制单个 SQLite 文件并假定其一定一致。

## 恢复

1. 停止容器。
2. 备份当前损坏或待替换的数据，便于回退。
3. 恢复完整 `STORAGE_PATH`。
4. 恢复 `MONITOR_HOST_PATH`，并尽可能保持目录结构。
5. 修正 UID/GID 和目录权限。
6. 启动容器。
7. 检查健康状态、登录、作品数量、阅读进度和文件打开情况。

```bash
docker compose up -d
docker compose logs --tail=100 web
curl http://127.0.0.1:3000/api/health
```

## 恢复后的常见问题

- **无法登录**：确认数据库和会话密钥来自同一套备份。
- **作品存在但文件打不开**：确认原始目录已恢复且容器路径仍为 `/monitor`。
- **权限错误**：确认 `PUID`/`PGID` 与恢复目录所有权匹配。
- **封面暂时缺失**：缓存可能需要重新生成。
- **导入重复**：不要在恢复后立即重新扫描未确认的重复目录。

执行恢复前，优先保留当前数据副本；不要直接覆盖唯一一份数据库。
