# Supported Formats

[Home](Home) · [简体中文](zh-CN-Supported-Formats) · [User Guide](en-US-User-Guide)

| Media type | Formats | Processing |
| --- | --- | --- |
| Ebooks | EPUB | Imported and read directly |
| Kindle/text ebooks | MOBI, AZW, AZW3, PRC | Converted to EPUB with libmobi; source retained |
| Text ebooks | FB2, TXT | Converted to EPUB with the built-in converter; source retained |
| Documents | PDF | Imported and read directly |
| Comics | CBZ, ZIP image archives | Read as ordered image pages |
| Audiobooks | M4B, M4A, MP3 | Audio and chapter/track metadata are imported |

## DRM

DRM-protected Kindle and other protected files are not supported. The project does not remove or bypass DRM.

## Automatic conversion

The persistent Python worker handles conversion:

- MOBI, AZW, AZW3, and PRC require `mobitool`;
- FB2 and TXT use the built-in converter;
- generated EPUB files are validated before publication;
- source files are retained and conversion provenance is recorded.

Configuration:

```dotenv
EBOOK_CONVERSION_ENABLED=true
LIBMOBI_BIN=mobitool
EBOOK_CONVERSION_TIMEOUT_SECONDS=600
```

The production image contains the required libmobi tools. Install them separately for local development.

## Comic recommendations

- Use browser-readable PNG, JPEG, or WebP images inside ZIP/CBZ.
- Use consistently zero-padded names such as `001.jpg`, `002.jpg`.
- Avoid unnecessary nested directories, system files, and damaged images.
- Very large images or archives increase extraction and initial load time.

## Audiobook recommendations

- Keep multi-track books in one work directory with ordered filenames.
- Embedded M4B chapters generally provide the best chapter experience.
- Consistent title, author, album, and track numbers improve identification.
- Actual codec playback depends on the client browser and operating system.

## Recognition failures

Make sure the extension matches the real file content. Renaming an extension does not convert a file. Check the import task details and system logs for the exact failure.
