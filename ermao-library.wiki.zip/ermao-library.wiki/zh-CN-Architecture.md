# 系统架构

[返回首页](Home) · [English](en-US-Architecture) · [开发指南](zh-CN-Development)

生产环境使用单个统一镜像，对外提供一个 Web 端口。

```mermaid
flowchart LR
    Client["浏览器 / PWA"] -->|HTTP 3000| Web["Next.js Web"]
    Web -->|/api/*| API["FastAPI API<br/>127.0.0.1:8000"]
    API --> DB["SQLite"]
    API --> Storage["应用存储<br/>/app/storage"]
    Worker["Python Import Worker"] --> DB
    Worker --> Monitor["原始读物<br/>/monitor"]
    Worker --> Storage
    Web --> Monitor
```

## 组件

### Next.js Web

- Next.js 14、React 18、TypeScript 和 Tailwind CSS
- 提供桌面、移动端与 PWA 界面
- 负责书库、详情、设置、阅读器和播放器页面
- 将 `/api/*` 转发到容器内 FastAPI

### FastAPI API

- Python、FastAPI 和 SQLAlchemy
- 负责账户、书库数据、设置、备份、健康检查和媒体相关接口
- 启动时初始化或升级 SQLite schema
- 在统一容器内监听 `127.0.0.1:8000`

### Python Worker

- 持久化处理导入和监控队列
- 使用 Watchdog 发现监控目录变化
- 解析元数据、封面、章节、音频信息和漫画页面
- 使用 libmobi、EbookLib、lxml 和 Mutagen 等组件
- 将支持的文本电子书转换为 EPUB

### SQLite

SQLite 是当前唯一支持的数据库，默认位于：

```text
STORAGE_ROOT/database/shuku.sqlite3
```

数据库保存账户、作品、版本、导入任务、阅读进度和系统设置等结构化数据。原始读物不存入数据库。

## 文件边界

- `/monitor`：原始读物及允许监控/上传的目录
- `/app/storage`：数据库、会话密钥、缓存、日志和派生文件
- 原始文件在转换和导入后继续保留
- 目录级备份必须覆盖上述两个挂载点

## 阅读器与播放器

- EPUB：通过官方 EPUB.js npm 依赖及项目自身适配层集成
- PDF：PDF.js
- 漫画：项目自研的漫画阅读适配器
- 有声书：HTML5 Audio 与项目播放器状态管理

EPUB.js 被视为不可修改的第三方依赖；阅读器行为由项目自己的控制器、输入处理和展示层通过其公共 API 实现。

## 国际化

Web 支持 `zh-CN` 和 `en-US`。界面消息由 `apps/web/i18n` 统一管理，日期、数字和动态内容应按当前语言环境格式化。

## 运行与健康检查

统一启动脚本运行：

```text
uvicorn app.main:app
python -m app.worker.main
node apps/web/server.js
```

健康检查入口：

```text
/api/health
/api/system/health
```

部署时只需暴露 Web 端口。API 和 Worker 在统一容器内部协作。
