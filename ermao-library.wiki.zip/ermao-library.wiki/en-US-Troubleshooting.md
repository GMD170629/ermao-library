# Troubleshooting

[Home](Home) · [简体中文](zh-CN-Troubleshooting) · [Configuration](en-US-Configuration)

Start with:

```bash
docker compose ps
docker compose logs --tail=200 web
curl -i http://127.0.0.1:3000/api/health
```

When reporting an issue, include the application version, host architecture, deployment method, browser, and reproduction steps. Remove email addresses, paths, tokens, and other private information from logs.

## Container fails to start or keeps restarting

Check that:

- `STORAGE_PATH` exists and is writable;
- `PUID`/`PGID` match directory permissions;
- `WEB_PORT` is not already in use;
- the disk has free space;
- the host is `amd64` or `arm64`.

```bash
docker compose config
docker inspect shuku-prod-web --format '{{.State.Status}} {{.State.Health.Status}}'
```

## The site is unreachable

- Local access: check the port mapping in `docker compose ps`.
- LAN access: allow `WEB_PORT` through the firewall.
- Domain access: check the reverse proxy, certificate, and `PUBLIC_APP_URL`.
- One-browser failure: clear site data and check whether an installed PWA still points to an old URL.

## 502 or unavailable API

The unified container runs Next.js, FastAPI, and the worker together. Check logs for API startup failures, database permissions, or worker exceptions. External clients use web port `3000`; internal port `8000` is not the primary entry point.

## Watched directory cannot be added or read

- The container path must remain under `/monitor`.
- The host directory must be mounted at `/monitor`.
- The container user needs read and write permissions.
- NAS permissions, ACLs, and network-share mounts can each impose restrictions.

```bash
docker compose exec web sh -lc 'id && ls -ld /monitor /app/storage'
```

## Files are not imported automatically

1. Confirm that the folder is enabled under **Settings → Library Sources and Import**.
2. Confirm that the file is inside the enabled folder.
3. Review queued and failed import tasks.
4. Review worker logs.
5. Use the rescan action instead of repeatedly copying the same file.

## MOBI/AZW/AZW3/PRC conversion fails

- The production image should include `mobitool`.
- Confirm `EBOOK_CONVERSION_ENABLED=true`.
- Check the timeout and source-file integrity.
- DRM files are unsupported.

Local development:

```bash
command -v mobitool
mobitool --help
```

## EPUB, PDF, or comic does not open

- Confirm the source file still exists at the mounted path.
- Check for an empty, corrupted, or DRM-protected file.
- Review browser developer tools and server logs.
- Compare with a known-good file to distinguish file and reader problems.
- Make sure the reverse proxy supports streaming and range requests.

## Reading/listening progress does not synchronize

- Use the same account and server on every device.
- Check whether the client is offline.
- Allow progress to save before closing the page.
- Check system clocks and proxy cache rules.

## SMTP or Kindle delivery fails

- Verify host, port, username, and password.
- Verify STARTTLS/SSL mode.
- Confirm sender verification with the mail provider.
- Confirm the sender is approved by Kindle.
- Check format and attachment-size limits.
- Review delivery history and system logs.

## Forgotten password

After requesting a reset, find `reset-password.html`:

- watched library root when configured;
- otherwise `STORAGE_ROOT/password-reset`.

The token expires after 30 minutes and can be used only once.

## Still unresolved

Open a [GitHub Issue](https://github.com/GMD170629/ermao-library/issues) with minimal reproduction details and sanitized logs. Never post secrets, passwords, or a complete production environment file.
