# Development Guide

[Home](Home) · [简体中文](zh-CN-Development) · [Architecture](en-US-Architecture)

## Runtime versions

Use the repository-declared versions:

- Node.js `20.20.2`
- pnpm `9.12.2`
- Python `3.11.15`

Node is recorded in `.nvmrc`, and Python in `apps/api-python/.python-version`. Do not run the project tests with Node.js 22 or Python 3.12.

## Get the source

```bash
git clone git@github.com:GMD170629/ermao-library.git
cd ermao-library
pnpm install
cp .env.example .env
pnpm dev:test
```

Default URL:

```text
http://localhost:3000
```

Create the initial administrator through the setup wizard when the development database is empty.

## Repository layout

```text
apps/
  web/           Next.js Web
  api-python/    FastAPI API and import worker
packages/
  reader-core/   Reader core
  shared/        Shared code
  ui/            UI package
scripts/         Build, validation, and smoke checks
deploy/          Platform deployment and fnOS resources
docs/            Design, deployment, and acceptance documentation
```

## Common checks

```bash
pnpm --filter @shuku/web typecheck
pnpm --filter @shuku/web build
cd apps/api-python && uv run --extra dev pytest -q
pnpm fnos:validate
```

Backend migration and runtime checks:

```bash
pnpm verify:python-backend
pnpm smoke:python-api
pnpm smoke:python-worker
pnpm smoke:python-worker-import
pnpm smoke:python-sample
```

Internationalization:

```bash
cd apps/web
pnpm i18n:check
```

Every user-visible change must include deliberate `zh-CN` and `en-US` copy with matching interpolation placeholders.

## Python API

```bash
cd apps/api-python
uv sync --extra dev
cp .env.example .env
uv run uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Run the worker separately:

```bash
python -m app.worker.main
```

## Change principles

- Do not modify `node_modules/epubjs`, vendor its source, or add behavioral patches.
- Integrate EPUB.js only through public APIs and project-owned adapters.
- Consider desktop, mobile, PWA, and both locales for user-visible features.
- When fixing an interaction, inspect related keyboard, pointer, touch, focus, and state-recovery behavior.
- Never commit `.env`, databases, session keys, or real library content.

## Before committing

Run type checking, builds, Pytest, i18n validation, and relevant smoke or acceptance checks in proportion to the change. Commit messages should explain intent. Update the README, Wiki, or repository `docs/` for user-visible behavior changes.

More backend details: [Python API README](https://github.com/GMD170629/ermao-library/blob/main/apps/api-python/README.md)
