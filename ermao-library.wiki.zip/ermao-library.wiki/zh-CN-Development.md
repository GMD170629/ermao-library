# 开发指南

[返回首页](Home) · [English](en-US-Development) · [系统架构](zh-CN-Architecture)

## 运行环境

使用仓库声明的版本：

- Node.js `20.20.2`
- pnpm `9.12.2`
- Python `3.11.15`

Node 版本记录在 `.nvmrc`，Python 版本记录在 `apps/api-python/.python-version`。不要使用 Node.js 22 或 Python 3.12 运行项目测试。

## 获取代码

```bash
git clone git@github.com:GMD170629/ermao-library.git
cd ermao-library
pnpm install
cp .env.example .env
pnpm dev:test
```

默认访问地址：

```text
http://localhost:3000
```

空数据库首次启动时，通过设置向导创建初始管理员。

## 项目结构

```text
apps/
  web/           Next.js Web
  api-python/    FastAPI API 与导入 Worker
packages/
  reader-core/   阅读器核心
  shared/        共享代码
  ui/            UI 包
scripts/         构建、验证与冒烟测试
deploy/          平台部署与 fnOS 资源
docs/            设计、部署和验收文档
```

## 常用检查

```bash
pnpm --filter @shuku/web typecheck
pnpm --filter @shuku/web build
cd apps/api-python && uv run --extra dev pytest -q
pnpm fnos:validate
```

后端迁移与运行时检查：

```bash
pnpm verify:python-backend
pnpm smoke:python-api
pnpm smoke:python-worker
pnpm smoke:python-worker-import
pnpm smoke:python-sample
```

国际化检查：

```bash
cd apps/web
pnpm i18n:check
```

任何用户可见变更都必须同时提供 `zh-CN` 和 `en-US` 文案，并保持插值占位符一致。

## Python API

```bash
cd apps/api-python
uv sync --extra dev
cp .env.example .env
uv run uvicorn app.main:app --host 0.0.0.0 --port 8000
```

单独运行 Worker：

```bash
python -m app.worker.main
```

## 代码变更原则

- 不要修改 `node_modules/epubjs`、供应商源码或为 EPUB.js 添加行为补丁
- 阅读器集成只使用 EPUB.js 公共 API 和项目自己的适配层
- 用户可见功能同时考虑桌面、移动端、PWA 和中英文
- 修复交互缺陷时检查同一能力面的键盘、鼠标、触摸、焦点和状态恢复
- 不提交 `.env`、数据库、会话密钥或真实书库内容

## 提交前

根据改动范围运行类型检查、构建、Pytest、i18n 检查和相关冒烟/验收测试。提交信息应说明变更意图；对用户可见的行为变更同时更新 README、Wiki 或仓库内 `docs/`。

更多后端信息：[Python API README](https://github.com/GMD170629/ermao-library/blob/main/apps/api-python/README.md)
