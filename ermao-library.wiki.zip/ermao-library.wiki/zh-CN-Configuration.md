# 配置说明

[返回首页](Home) · [English](en-US-Configuration) · [安装与更新](zh-CN-Installation)

Docker Compose 可以通过同目录的 `.env` 文件或 `environment` 配置应用。敏感配置不要提交到公开仓库。

## Docker Compose 变量

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `WEB_PORT` | `3000` | 宿主机 Web 端口 |
| `PUID` | `1000` | 容器进程使用的宿主机用户 ID |
| `PGID` | `1000` | 容器进程使用的宿主机组 ID |
| `MONITOR_HOST_PATH` | `./monitor` | 宿主机原始读物目录 |
| `STORAGE_PATH` | `./data/storage` | 宿主机应用数据目录 |

## 应用变量

| 变量 | 示例/默认值 | 说明 |
| --- | --- | --- |
| `STORAGE_ROOT` | `/app/storage` | 容器内应用数据根目录 |
| `MONITOR_ROOT` | `/monitor` | 容器内允许浏览和监控的根目录 |
| `PUBLIC_APP_URL` | `https://books.example.com` | 应用对外访问地址 |
| `SESSION_SECRET` | 至少 32 个字符 | 会话签名密钥；生产环境必须使用随机值 |
| `EBOOK_CONVERSION_ENABLED` | `true` | 是否启用文本电子书自动转换 |
| `LIBMOBI_BIN` | `mobitool` | libmobi 可执行文件名或路径 |
| `EBOOK_CONVERSION_TIMEOUT_SECONDS` | `600` | 单次转换超时秒数 |
| `FILE_STREAMS_PER_USER` | `4` | 每个用户允许的文件流并发数 |
| `SLOW_FILE_REQUEST_MS` | `1500` | 慢文件请求判定阈值 |
| `KINDLE_SEND_QUEUE_ENABLED` | `true` | 是否运行 Kindle 发送队列 |
| `KINDLE_SEND_QUEUE_INTERVAL_SECONDS` | `5` | Kindle 队列轮询间隔 |

`STORAGE_ROOT` 和 `MONITOR_ROOT` 是容器内部路径；正常 Docker 部署不应把它们改成宿主机路径。

## 会话密钥

生产环境应生成随机密钥：

```bash
openssl rand -hex 32
```

然后写入 `.env`：

```dotenv
SESSION_SECRET=生成的随机字符串
```

如果容器首次启动时自动生成了会话密钥，它会保存在持久化存储中。迁移服务器时应复制完整的 `STORAGE_PATH`。

## SMTP 与 Kindle

邮件服务器和 Kindle 收件地址主要在应用的“设置 → 邮件与 Kindle”中管理。部署层支持：

```dotenv
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USERNAME=
SMTP_PASSWORD=
SMTP_FROM=books@example.com
SMTP_STARTTLS=true
SMTP_USE_SSL=false
KINDLE_SEND_QUEUE_ENABLED=true
KINDLE_SEND_QUEUE_INTERVAL_SECONDS=5
```

- 通常端口 `587` 使用 `SMTP_STARTTLS=true`
- 通常端口 `465` 使用 `SMTP_USE_SSL=true`
- 不要同时启用不兼容的 TLS 模式
- 发件地址应符合邮件服务商的验证要求
- Kindle 端还需要将发件地址加入认可的个人文档邮箱列表

## 反向代理地址

使用 HTTPS 域名时设置：

```dotenv
PUBLIC_APP_URL=https://books.example.com
```

该地址用于生成外部可访问的链接。反向代理必须正确传递原始协议和主机信息。

## 修改配置后生效

```bash
docker compose up -d
```

如果只改变 `.env`，Compose 会重新创建需要更新的容器。随后使用 `docker compose logs --tail=100 web` 检查启动日志。

完整示例：[`.env.production.example`](https://github.com/GMD170629/ermao-library/blob/main/.env.production.example)
