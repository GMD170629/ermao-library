# 安装与更新

[返回首页](Home) · [English](en-US-Installation) · [快速开始](zh-CN-Quick-Start)

## 部署要求

- 安装 Docker Engine 和 Docker Compose v2
- 支持 `linux/amd64` 或 `linux/arm64`
- 为应用准备持久化存储目录和书库目录
- 确保映射端口可从需要使用的设备访问

生产环境推荐使用仓库提供的 [`docker-compose.prod.yml`](https://github.com/GMD170629/ermao-library/blob/main/docker-compose.prod.yml)，镜像为 `gamersgu/shuku-starship-web:prod`。

## 目录与权限

| 宿主机目录 | 容器目录 | 用途 |
| --- | --- | --- |
| `${MONITOR_HOST_PATH:-./monitor}` | `/monitor` | 原始读物及监控文件夹 |
| `${STORAGE_PATH:-./data/storage}` | `/app/storage` | SQLite、缓存、日志、会话密钥及派生文件 |

容器默认以 `1000:1000` 运行。可以通过 `PUID` 和 `PGID` 调整，但对应用户必须能读写上述两个目录。

Linux 示例：

```bash
id
sudo chown -R 1000:1000 ./monitor ./data/storage
sudo chmod -R u+rwX ./monitor ./data/storage
```

不要为了省事将数据目录设置为全员可写。NAS 上应使用其文件管理器或权限面板，将目录授权给容器所使用的 UID/GID。

## 使用 `.env`

可以在 `compose.yaml` 同目录创建 `.env`：

```dotenv
WEB_PORT=3000
PUID=1000
PGID=1000
MONITOR_HOST_PATH=./monitor
STORAGE_PATH=./data/storage
```

更完整的示例见仓库的 [`.env.production.example`](https://github.com/GMD170629/ermao-library/blob/main/.env.production.example)。

## 启动和停止

```bash
docker compose up -d
docker compose ps
docker compose logs -f web
```

停止但保留数据：

```bash
docker compose down
```

## 更新

更新前建议先执行应用内数据库备份，并备份整个 `STORAGE_PATH`。

```bash
docker compose pull
docker compose up -d
docker compose ps
```

更新后确认：

- 容器状态为 `healthy`
- `/api/health` 返回成功
- 能正常登录、查看书库和打开读物
- 导入 Worker 正常处理新文件

## 迁移到另一台设备

1. 停止旧设备上的容器。
2. 复制完整的 `MONITOR_HOST_PATH` 和 `STORAGE_PATH`。
3. 在新设备上保持相同的容器挂载路径 `/monitor` 和 `/app/storage`。
4. 修正新设备上的 UID/GID 与目录权限。
5. 启动容器并验证数据库、封面和读物访问。

## 反向代理

如果通过域名和 HTTPS 访问：

- 将反向代理目标指向 `http://服务器地址:WEB_PORT`
- 将 `PUBLIC_APP_URL` 设为外部 HTTPS 地址
- 转发常见的 `Host`、`X-Forwarded-For` 和 `X-Forwarded-Proto` 请求头
- 不要把内部 FastAPI 端口 `8000` 直接暴露到公网

## 卸载

`docker compose down` 只删除容器和网络，不删除宿主机挂载目录。确认不再需要数据后，再手动处理 `MONITOR_HOST_PATH` 和 `STORAGE_PATH`。删除存储目录前务必先备份。
