# 二毛图书 Wiki

[简体中文](#简体中文) · [English](#english) · [GitHub 仓库](https://github.com/GMD170629/ermao-library)

二毛图书（shuku-starship）是一套面向个人与家庭的自托管数字书库，用于管理 NAS、家庭服务器或本地硬盘中的电子书、PDF、漫画和有声书。数据、账户、阅读进度和设置均保存在自己的设备上。

## 简体中文

### 使用与部署

- [快速开始](zh-CN-Quick-Start)：使用 Docker Compose 完成首次部署
- [安装与更新](zh-CN-Installation)：部署要求、目录挂载、更新与卸载
- [配置说明](zh-CN-Configuration)：环境变量、端口、目录和邮件配置
- [用户指南](zh-CN-User-Guide)：导入、整理、阅读、收听、Kindle 与 PWA
- [图书导入指南](zh-CN-Import-Guide)：上传、文件导入、偏好设置、命名与重新导入
- [支持格式](zh-CN-Supported-Formats)：电子书、PDF、漫画和有声书格式
- [备份与恢复](zh-CN-Backup-and-Recovery)：数据范围、备份策略和恢复注意事项
- [故障排查](zh-CN-Troubleshooting)：启动、权限、导入、转换和访问问题

### 项目开发

- [系统架构](zh-CN-Architecture)：Web、API、Worker、SQLite 与文件存储
- [开发指南](zh-CN-Development)：本地环境、常用命令和验证流程

## English

### Usage and deployment

- [Quick Start](en-US-Quick-Start)
- [Installation and Updates](en-US-Installation)
- [Configuration](en-US-Configuration)
- [User Guide](en-US-User-Guide)
- [Import Guide](en-US-Import-Guide)
- [Supported Formats](en-US-Supported-Formats)
- [Backup and Recovery](en-US-Backup-and-Recovery)
- [Troubleshooting](en-US-Troubleshooting)

### Development

- [Architecture](en-US-Architecture)
- [Development Guide](en-US-Development)

## 项目信息 / Project information

- 当前应用版本以系统“设置 → 关于”和仓库根目录 [`package.json`](https://github.com/GMD170629/ermao-library/blob/main/package.json) 为准。
- 问题反馈请使用 [GitHub Issues](https://github.com/GMD170629/ermao-library/issues)。
- QQ 交流群：`154560969`
- 本项目采用 [MIT License](https://github.com/GMD170629/ermao-library/blob/main/LICENSE)。

> Wiki 面向当前 `main` 分支维护。发布版本的行为如与 Wiki 不同，请以对应版本的 README、配置示例和应用内说明为准。
