# Installation and Updates

[Home](Home) · [简体中文](zh-CN-Installation) · [Quick Start](en-US-Quick-Start)

## Requirements

- Docker Engine and Docker Compose v2
- A `linux/amd64` or `linux/arm64` host
- Persistent directories for application data and original reading files
- A web port reachable from the devices that will use the application

For production, use [`docker-compose.prod.yml`](https://github.com/GMD170629/ermao-library/blob/main/docker-compose.prod.yml) and the `gamersgu/shuku-starship-web:prod` image.

## Directories and permissions

| Host directory | Container directory | Purpose |
| --- | --- | --- |
| `${MONITOR_HOST_PATH:-./monitor}` | `/monitor` | Original reading files and watched folders |
| `${STORAGE_PATH:-./data/storage}` | `/app/storage` | SQLite, cache, logs, session keys, and derived files |

The container runs as `1000:1000` by default. `PUID` and `PGID` can change this identity, but the selected user must have read and write access to both mounted directories.

Linux example:

```bash
id
sudo chown -R 1000:1000 ./monitor ./data/storage
sudo chmod -R u+rwX ./monitor ./data/storage
```

Avoid making the data directories world-writable. On a NAS, grant access to the selected UID/GID through the NAS permission manager.

## `.env`

Create `.env` next to `compose.yaml`:

```dotenv
WEB_PORT=3000
PUID=1000
PGID=1000
MONITOR_HOST_PATH=./monitor
STORAGE_PATH=./data/storage
```

See [`.env.production.example`](https://github.com/GMD170629/ermao-library/blob/main/.env.production.example) for the complete example.

## Start and stop

```bash
docker compose up -d
docker compose ps
docker compose logs -f web
```

Stop the stack while retaining data:

```bash
docker compose down
```

## Update

Create an application backup and back up the full `STORAGE_PATH` before updating.

```bash
docker compose pull
docker compose up -d
docker compose ps
```

After updating, verify that:

- the container becomes `healthy`;
- `/api/health` succeeds;
- sign-in, library browsing, and readers still work;
- the import worker processes a new file.

## Move to another host

1. Stop the container on the old host.
2. Copy the complete `MONITOR_HOST_PATH` and `STORAGE_PATH`.
3. Keep the container mount points `/monitor` and `/app/storage` on the new host.
4. Correct UID/GID ownership and permissions.
5. Start the container and verify the database, covers, and reading files.

## Reverse proxy

For a domain with HTTPS:

- proxy to `http://server-address:WEB_PORT`;
- set `PUBLIC_APP_URL` to the external HTTPS URL;
- forward `Host`, `X-Forwarded-For`, and `X-Forwarded-Proto`;
- do not expose the internal FastAPI port `8000` directly to the internet.

## Uninstall

`docker compose down` removes containers and networks but does not remove mounted host directories. Back up and explicitly confirm the data is no longer needed before deleting `MONITOR_HOST_PATH` or `STORAGE_PATH`.
