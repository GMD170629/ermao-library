# 支持格式

[返回首页](Home) · [English](en-US-Supported-Formats) · [用户指南](zh-CN-User-Guide)

| 类型 | 支持格式 | 处理方式 |
| --- | --- | --- |
| 电子书 | EPUB | 直接导入和在线阅读 |
| Kindle/文本电子书 | MOBI、AZW、AZW3、PRC | 使用 libmobi 转换为 EPUB，保留源文件 |
| 文本电子书 | FB2、TXT | 使用内置转换器生成 EPUB，保留源文件 |
| 文档 | PDF | 直接导入和在线阅读 |
| 漫画 | CBZ、ZIP 图片包 | 按图片页读取 |
| 有声书 | M4B、M4A、MP3 | 读取音频与章节/轨道信息 |

## DRM

不支持带 DRM 的 Kindle 或其他受保护文件。项目不会移除或绕过 DRM。

## 自动转换

自动转换由持久化 Python Worker 处理：

- MOBI、AZW、AZW3 和 PRC 依赖 `mobitool`
- FB2 和 TXT 使用应用内置转换器
- 转换后的 EPUB 会在发布到书库前进行验证
- 原始文件保留，并记录转换来源

相关配置：

```dotenv
EBOOK_CONVERSION_ENABLED=true
LIBMOBI_BIN=mobitool
EBOOK_CONVERSION_TIMEOUT_SECONDS=600
```

生产镜像已经包含所需的 libmobi 工具。本地开发环境需要自行安装。

## 漫画文件建议

- ZIP/CBZ 内使用 PNG、JPEG 或 WebP 等浏览器可读取图片
- 文件名使用统一的零填充编号，例如 `001.jpg`、`002.jpg`
- 避免多层无关目录、系统隐藏文件和损坏图片
- 超大图片或压缩包会增加解压和首次加载时间

## 有声书建议

- 多轨作品放在同一作品目录中，并使用有序文件名
- M4B 的内嵌章节体验通常更完整
- 统一标题、作者、专辑和轨道编号有利于识别
- 浏览器实际可播放的编码仍取决于客户端平台

## 文件识别失败

确认扩展名与真实文件内容一致。仅修改扩展名不会把文件转换成对应格式。失败详情可在导入任务和系统日志中查看。
