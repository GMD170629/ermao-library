# User Guide

[Home](Home) · [简体中文](zh-CN-User-Guide) · [Supported Formats](en-US-Supported-Formats)

## First-time setup

When an empty database is opened, the setup wizard asks you to:

1. Create the initial administrator.
2. Add one or more watched folders.
3. Confirm the basic library settings.

There is no default account. Use a unique, sufficiently long administrator password.

## Import reading files

Reading files can be uploaded from a browser or imported automatically from watched NAS/server directories. The standalone [Import Guide](en-US-Import-Guide) covers:

- complete upload and file-import procedures;
- watched-folder and file-manager configuration;
- every import preference;
- naming conventions for ebooks/documents, comics, and audiobooks;
- failures, incorrect grouping, deletion, and re-import.

Text-based ebooks may be converted to EPUB before becoming readable. The source file is retained.

## Organize the library

- Search and filter by title, author, media type, format, tag, series, and reading status.
- Group items on custom shelves.
- Manage statuses such as unread, reading, and completed.
- Edit titles, authors, covers, tags, series, and volume information.
- Enrich metadata through Smart Organization.
- Review duplicates, alternate editions, and consecutive volumes.

Metadata integrations can include supported Douban, Bangumi, and AI providers. Availability and terms are controlled by those external services.

## Read ebooks, PDFs, and comics

Select an edition from the work detail page. Depending on format, readers provide:

- table-of-contents or chapter navigation;
- keyboard, button, tap-zone, or touch navigation;
- progress positioning;
- font, theme, and display settings;
- format-appropriate EPUB, PDF, or comic modes.

Reading progress is saved and synchronized across devices using the same server. Browser privacy restrictions, offline state, or account changes can delay synchronization.

## Listen to audiobooks

The audio player supports:

- single-file, multi-track, and multi-volume books;
- a volume dropdown on the work page and in the mini player;
- chapter navigation;
- play/pause, seeking, forward, and rewind;
- speed and volume controls;
- a sleep timer;
- a cross-page mini player and listening progress.

Each volume of a multi-volume audiobook has its own tracks, chapters, and progress. The dropdown shows the current volume and opens an equal-width, scrollable list whose scrollbar is hidden. Reopening the audiobook restores the most recently played volume when possible, otherwise the first volume is selected.

At the end of a volume, the player saves that volume as complete and stops instead of automatically starting the next volume. Overall audiobook progress is duration-weighted across volumes, and the book is marked complete only after every volume is complete.

## Send to Kindle

1. Open **Settings → Email and Kindle**.
2. Configure the SMTP server.
3. Enter the Kindle recipient address.
4. Approve the sender in the Amazon/Kindle account.
5. Send an EPUB or PDF from a work page and review delivery history.

For failures, check SMTP credentials, TLS mode, sender verification, attachment limits, and the Kindle approved-sender list.

## Data and accounts

The settings center covers profiles, passwords, user permissions, database backup and recovery, system health, and logs. Exact administrator capabilities depend on the installed application version.

For a forgotten password, the server creates a local `reset-password.html` file. It is written to the watched library root when available, otherwise to the `password-reset` directory under application storage. The token expires after 30 minutes and can be used only once.

## PWA

Supported browsers can install the app as a PWA:

- Android/desktop Chrome: use **Install app**.
- iOS/iPadOS Safari: **Share → Add to Home Screen**.

The application shell may be cached, but library data, synchronization, and media operations still require access to the server.
