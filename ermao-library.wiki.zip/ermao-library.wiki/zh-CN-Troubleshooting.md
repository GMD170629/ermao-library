# 故障排查

[返回首页](Home) · [English](en-US-Troubleshooting) · [配置说明](zh-CN-Configuration)

先收集三个基本信息：

```bash
docker compose ps
docker compose logs --tail=200 web
curl -i http://127.0.0.1:3000/api/health
```

报告问题时请说明应用版本、设备架构、部署方式、浏览器和可复现步骤。日志中如含邮箱、路径、令牌或其他隐私信息，请先脱敏。

## 容器无法启动或反复重启

检查：

- `STORAGE_PATH` 是否存在并可写
- `PUID`/`PGID` 是否与目录权限匹配
- `WEB_PORT` 是否被其他服务占用
- 磁盘是否已满
- 镜像架构是否为 `amd64` 或 `arm64`

```bash
docker compose config
docker inspect shuku-prod-web --format '{{.State.Status}} {{.State.Health.Status}}'
```

## 页面无法访问

- 本机访问：检查 `docker compose ps` 中的端口映射
- 局域网访问：确认防火墙允许 `WEB_PORT`
- 域名访问：检查反向代理、证书和 `PUBLIC_APP_URL`
- 只在部分浏览器失败：清除该站点缓存并检查 PWA 是否仍指向旧地址

## 显示 502 或 API 不可用

统一容器内部同时运行 Next.js、FastAPI 和 Worker。检查日志中是否有 API 启动失败、数据库权限或 Python Worker 异常。外部只需要访问 Web 端口 `3000`；不要把内部 `8000` 当作主要入口。

## 无法添加或读取监控目录

- 容器内路径必须位于 `/monitor` 下
- 宿主机实际目录必须正确挂载到 `/monitor`
- 容器用户需要读写权限
- NAS 权限、ACL 和网络共享挂载可能同时限制访问

进入容器检查：

```bash
docker compose exec web sh -lc 'id && ls -ld /monitor /app/storage'
```

## 文件没有自动导入

1. 确认目录已经在“设置 → 书库来源与导入”中启用。
2. 确认文件位于启用目录范围内。
3. 查看导入任务是否排队或失败。
4. 查看 Worker 日志。
5. 尝试从界面重新扫描，而不是反复复制同一个文件。

## MOBI/AZW/AZW3/PRC 转换失败

- 生产镜像应自带 `mobitool`
- 确认 `EBOOK_CONVERSION_ENABLED=true`
- 检查转换超时和源文件是否损坏
- DRM 文件不受支持

本地开发环境：

```bash
command -v mobitool
mobitool --help
```

## EPUB、PDF 或漫画打不开

- 确认源文件仍在原来的挂载路径
- 确认文件不是零字节、损坏或受 DRM 保护
- 查看浏览器开发者工具和服务端日志
- 使用另一个已知正常文件判断是单文件问题还是阅读器问题
- 检查反向代理是否支持文件流和范围请求

## 阅读/收听进度不同步

- 确认不同设备登录的是同一账户和同一服务器
- 检查客户端是否离线
- 等待页面完成保存后再关闭
- 检查系统时间和反向代理缓存规则

## SMTP 或 Kindle 发送失败

- 核对主机、端口、用户名和密码
- 核对 STARTTLS/SSL 模式
- 确认发件地址已通过邮件服务商验证
- 确认 Kindle 已认可发件地址
- 检查附件格式和邮件服务商大小限制
- 查看 Kindle 发送记录和系统日志

## 忘记密码

发起密码重置后查找 `reset-password.html`：

- 有监控目录：监控书库根目录
- 无监控目录：`STORAGE_ROOT/password-reset`

重置令牌 30 分钟后失效，并且只能使用一次。

## 仍无法解决

在 [GitHub Issues](https://github.com/GMD170629/ermao-library/issues) 提交最小可复现信息，并附脱敏后的相关日志。安全漏洞不要公开粘贴密钥、密码或完整环境文件。
